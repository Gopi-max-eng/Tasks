namespace Motor_Carrier_Freight {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Motor_Carrier_Freight.Inputschema", typeof(global::Motor_Carrier_Freight.Inputschema))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Motor_Carrier_Freight.X12_00401_810", typeof(global::Motor_Carrier_Freight.X12_00401_810))]
    public sealed class Map4 : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp"" version=""1.0"" xmlns:ns0=""http://schemas.microsoft.com/BizTalk/EDI/X12/2006"" xmlns:s0=""http://Motor_Carrier_Freight.Inputschema"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:Root"" />
  </xsl:template>
  <xsl:template match=""/s0:Root"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringTrimLeft(string(Address/text()))"" />
    <ns0:X12_00401_810>
      <ns0:CUR>
        <CUR01>
          <xsl:value-of select=""ResellerName/text()"" />
        </CUR01>
        <CUR02>
          <xsl:value-of select=""Purchaseordernumber/text()"" />
        </CUR02>
      </ns0:CUR>
      <ns0:REF>
        <REF01>
          <xsl:value-of select=""$var:v1"" />
        </REF01>
        <REF02>
          <xsl:value-of select=""City/text()"" />
        </REF02>
      </ns0:REF>
    </ns0:X12_00401_810>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringTrimLeft(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimStart(null);
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _xsltEngine = @"";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Motor_Carrier_Freight.Inputschema";
        
        private const global::Motor_Carrier_Freight.Inputschema _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Motor_Carrier_Freight.X12_00401_810";
        
        private const global::Motor_Carrier_Freight.X12_00401_810 _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltEngine {
            get {
                return _xsltEngine;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Motor_Carrier_Freight.Inputschema";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Motor_Carrier_Freight.X12_00401_810";
                return _TrgSchemas;
            }
        }
    }
}
