﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OfficeOpenXml;

class Program
{
    static void Main(string[] args)
    {
        
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        CompareFoldersAndExport(@"F:\Actual\Path\To\FolderA", @"F:\Actual\Path\To\FolderB", @"F:\Output\Path\To\Export.xlsx");

    }

    static void CompareFoldersAndExport(string folderA, string folderB, string outputPath)
    {
        var filesA = Directory.GetFiles(folderA);
        var filesB = Directory.GetFiles(folderB);

        var fileNamesA = filesA.Select(Path.GetFileName).ToList();
        var fileNamesB = filesB.Select(Path.GetFileName).ToList();

        // List to hold results
        var results = new List<string>();

        // Check for files that are not in folder B
        foreach (var fileName in fileNamesA)
        {
            if (!fileNamesB.Contains(fileName))
            {
                results.Add($"Missing in Folder B: {fileName}");
            }
            else
            {
                string filePathA = Path.Combine(folderA, fileName);
                string filePathB = Path.Combine(folderB, fileName);
                if (!CompareFileContents(filePathA, filePathB))
                {
                    results.Add($"Different content: {fileName}");
                }
            }
        }

        // Check for files that are not in folder A
        foreach (var fileName in fileNamesB)
        {
            if (!fileNamesA.Contains(fileName))
            {
                results.Add($"Missing in Folder A: {fileName}");
            }
        }

        // Export results to Excel
        ExportToExcel(results, outputPath);
    }

    static bool CompareFileContents(string filePathA, string filePathB)
    {
        var contentA = File.ReadAllText(filePathA);
        var contentB = File.ReadAllText(filePathB);
        return contentA == contentB;
    }

    static void ExportToExcel(List<string> results, string outputPath)
    {
        using ( var package = new ExcelPackage())
        {
            var worksheet = package.Workbook.Worksheets.Add("Comparison Results");

            // Add header
            worksheet.Cells[1, 1].Value = "Results";
            for (int i = 0; i < results.Count; i++)
            {
                worksheet.Cells[i + 2, 1].Value = results[i];
            }

            // Save to file
            FileInfo excelFile = new FileInfo(outputPath);
            package.SaveAs(excelFile);
        }

        Console.WriteLine($"Comparison results saved to {outputPath}");
    }
}
